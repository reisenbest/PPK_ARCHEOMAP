
import Map from './ol/ol.js';
import View from './ol/View.js';
import TileLayer from './ol/layer/Tile.js';
import XYZ from './ol/source/XYZ.js';
import ImageLayer from './ol/layer/Image.js';
import Static from './ol/source/ImageStatic.js';
import {fromLonLat, get as getProjection} from './ol/proj.js';

const map = new Map({
  target: 'map',
  layers: [
    new TileLayer({
      source: new XYZ({
        url: './tiles/{z}/{x}/{y}.png',
        maxZoom: 18,
        minZoom: 14
      })
    }),
    new ImageLayer({
      source: new Static({
        url: './images/historical_overlay.png',
        imageExtent: [3373325.38, 8438383.73, 3374625.38, 8439383.73], // пример, подгонишь
        projection: getProjection('EPSG:3857')
      })
    })
  ],
  view: new View({
    center: fromLonLat([30.3167, 59.9500]),
    zoom: 15
  })
});
